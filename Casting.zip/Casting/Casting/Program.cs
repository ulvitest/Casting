﻿using System;

namespace Casting
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Upcasting,implicit,boxing
            //Object[] arr = { 1, "string", false };
            //Eagle eagle = new Eagle();
            //Animal animal = eagle;

            //Console.WriteLine(animal.GetType());
            //Shark shark = new Shark();
            //Animal[] arr = { eagle, shark };
            #endregion

            #region Downcasting,expilict,unboxing
            Eagle eagle = new Eagle();
            Shark shark = new Shark();

            #region security-way-1
            Animal animal = eagle;
            //downcasting securty way - 1(is)
            //if (animal is Eagle eagle1)
            //{
            //    //Eagle eagle1 = (Eagle)animal;
            //    eagle1.Eat();
            //}
            //else
            //{
            //    Console.WriteLine("wrong");
            //}
            #endregion

            //downcasting securty way -2 (as)
            #region security-way-2
            //Animal animal = eagle;
            //Eagle eagle1 = animal as Eagle;
            //if (eagle1!=null)
            //{
            //    eagle1.Eat();
            //}
            //else
            //{
            //    Console.WriteLine("wrong");
            //}
            #endregion

            #endregion

            #region task
            //Shark shark1 = new Shark();
            //Eagle eagle1 = new Eagle();
            //Object[] arr = {7, shark1, eagle1,5,"lorem" };
            //foreach (var item in arr)
            //{
            //Animal animal1 =(Animal) item;
            //    if (item is Animal animal1)
            //    {
            //        animal1.Eat();
            //    }

            //}
            #endregion

            #region implicit,explicit operatorlar
            //int a = 5;
            //long b = 15000000000;
            //int c = (int)b;
            //string num = "12bn3";
            //int result;
            //bool isConvert = int.TryParse(num, out result);
            //Console.WriteLine(isConvert);
            //Console.WriteLine(result);
            Manat manat = new Manat(340);
            Dollar dollar =(Dollar)manat;
            //Console.WriteLine(dollar.Usd);
            #endregion

            #region Operator overloading
            Person p1 = new Person(25,"Ehmed");
            Person p2 = new Person(20, "Yusif");
            //Console.WriteLine(p1>p2);
            Console.WriteLine(p1+p2);
            #endregion

        }
    }

    abstract class Animal
    {
        public abstract void Eat();
    }
    abstract class Bird : Animal
    {
        public abstract void Fly();

    }
    class Eagle : Bird
    {
        public int Age { get; set; }
        public override void Eat()
        {
            Console.WriteLine("eat as eagle"); ;
        }

        public override void Fly()
        {
            Console.WriteLine("fly as eagle") ;
        }
    }

    abstract class Fish : Animal
    {
        public int Teeth { get; set; }
        public abstract void Swim();
    }

    class Shark : Fish
    {
        public override void Eat()
        {
            Console.WriteLine("eat as shark");
        }

        public override void Swim()
        {
            Console.WriteLine("swim as Shark") ;
        }
    }

    class Dollar
    {
        public double Usd { get; set; }
        public Dollar(double usd)
        {
            Usd = usd;
        }
    }
    class Manat
    {
        public double Azn { get; set; }
        public Manat(double azn)
        {
            Azn = azn;
        }
        public static explicit operator Dollar(Manat m)
        {
            return new Dollar(m.Azn / 1.7);
        }
    }
    class Person
    {
        public int Age { get; set; }
        public string Name { get; set; }
        public Person(int age,string name)
        {
            Age = age;
            Name = name;
        }
        public static bool operator >(Person p1,Person p2)
        {
            return p1.Age > p2.Age;
        }
        public static bool operator <(Person p1, Person p2)
        {
            return p1.Age < p2.Age;
        }
        public static int operator +(Person p1, Person p2)
        {
            return p1.Age + p2.Age;
        }
    }
}
